package id.dfixer.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Icon

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    NativeFoundationScreen()
                }
            }
        }
    }
}

private data class Feature(val title: String, val detail: String)

@Composable
private fun NativeFoundationScreen() {
    val features = listOf(
        Feature("Transaksi", "Kasir dan pembayaran tunai"),
        Feature("Produk", "Kategori, harga, dan status produk"),
        Feature("Riwayat", "Cari transaksi dan cetak ulang struk"),
        Feature("Laporan", "Ringkasan penjualan"),
        Feature("Perangkat & PIN", "Akses lokal dan perangkat terdaftar"),
        Feature("Cloud", "Sinkronisasi opsional saat online")
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Default.PointOfSale, contentDescription = null)
            Column(modifier = Modifier.weight(1f)) {
                Text("D’Fixer POS", style = MaterialTheme.typography.headlineMedium)
                Text("Fondasi Android Native", style = MaterialTheme.typography.bodyMedium)
            }
            Icon(Icons.Default.CloudOff, contentDescription = "Cloud belum diaktifkan")
        }

        Card(colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )) {
            Column(Modifier.padding(16.dp)) {
                Text("Mode lokal", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Fondasi awal ini belum menyimpan transaksi. Database Room, autentikasi PIN, " +
                        "dan antrean sinkronisasi akan ditambahkan pada tahap berikutnya."
                )
            }
        }

        Text("Modul aplikasi", style = MaterialTheme.typography.titleLarge)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 220.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(features) { feature ->
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text(feature.title, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(feature.detail, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        Spacer(Modifier.height(4.dp))
        Button(onClick = { /* Navigation will be implemented with the POS flow. */ }) {
            Text("Fondasi UI saja — transaksi belum aktif")
        }
    }
}
